<?php
return
[
    'name'=>'getInfo',
    'description'=>'this api used to get all information of the application',
    'params'=>
        [

        ],
    'response'=>[
        [
            'status'=>200,
            'params'=>[
                'info'=>'<a href="#info">info</a>',
            ],
        ],

    ]
];
